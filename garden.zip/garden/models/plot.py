from odoo import models, fields, api
from odoo.exceptions import ValidationError


class Plot(models.Model):
    _name = 'plot'
    _description = 'Garden plot'

    name = fields.Char(string='Plot number')

    is_organic = fields.Boolean(
        string='Is Organic Garden',
        default=False
    )

    cycle_count = fields.Integer(
        string="Cycle",
        readonly=True,
        default=0,
    )

    slot_count = fields.Integer(
        string="Slot Count",
        compute='_compute_slot_count',
    )

    @api.depends('slot_ids')
    def _compute_slot_count(self):
        for rec in self:
            rec.slot_count = len(
                self.slot_ids.filtered(lambda s: s.owner_id))

    @api.constrains('note')
    def _check_note(self):
        for rec in self:
            if 'abc' in rec.note:
                raise ValidationError("abc is not allowed")

    @api.onchange('slot_count')
    def _onchange_slot_count(self):
        if self.slot_count == 5:
            self.note = False

    slot_ids = fields.One2many(
        comodel_name="plot.slot",
        inverse_name="plot_id",
        string="Slot",
    )

    gardener_ids = fields.Many2many(
        comodel_name='gardener',
        relation='plot_gardener_rel',
        column1='plot_id',
        column2='gardener_id',
        string='Gardener'
    )

    state = fields.Selection(
        [('draft', 'Draft'), ('running', 'Running'), ('done', 'Finished'), ('deny', 'Denied')],
        default='draft'
    )

    note = fields.Text()

    def set_to_running(self):
        self.state = 'running'
        self.note = " ".join(self.gardener_ids.mapped('name'))

    def running(self):
        self.state = 'running'

    def finish(self):
        self.state = 'done'

    def denied(self):
        self.state = 'deny'
