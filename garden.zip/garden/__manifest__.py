{
    'name': "Garden",
    'summary': """
        My Garden
    """,
    'version': '15.0.0.0.1',
    'author': " Roots",
    'website': 'https://roots.tech',
    'category': 'Tools',
    'license': 'LGPL-3',
    'contributors': [
        'Tewtawat Cha.',
    ],
    'depends': ['base'],
    'data': [
        'security/garden_security.xml',
        'security/ir.model.access.csv',
        'views/plot_views.xml',
        'views/gardener_views.xml',
        'views/plot_menus.xml',
    ],

    'application': True,
}
